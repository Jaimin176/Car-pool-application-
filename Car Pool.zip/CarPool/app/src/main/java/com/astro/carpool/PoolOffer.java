package com.astro.carpool;

public class PoolOffer {
    private String pickupLocation;
    private String dropoffLocation;
    private String date;
    private String time;
    private String availableSeats;
    private String price;
    private String vehicleType;
    private String additionalNotes;

    public PoolOffer() {
        // Default constructor required for Firebase
    }

    public PoolOffer(String pickupLocation, String dropoffLocation, String date,String time, String availableSeats,
                     String price, String vehicleType, String additionalNotes) {
        this.pickupLocation = pickupLocation;
        this.dropoffLocation = dropoffLocation;
        this.date = date;
        this.time = time;
        this.availableSeats = availableSeats;
        this.price = price;
        this.vehicleType = vehicleType;
        this.additionalNotes = additionalNotes;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPickUpPoint() {
        return pickupLocation;
    }

    public void setPickUpPoint(String pickUpPoint) {
        this.pickupLocation = pickUpPoint;
    }

    public String getDropPoint() {
        return dropoffLocation;
    }

    public void setDropPoint(String dropPoint) {
        this.dropoffLocation = dropPoint;
    }

    public String getPassengerCount() {
        return availableSeats;
    }

    public void setPassengerCount(String passengerCount) {
        this.availableSeats = passengerCount;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String passengerCount) {
        this.price = passengerCount;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String passengerCount) {
        this.vehicleType = passengerCount;
    }

    public String getAdditionalNotes() {
        return additionalNotes;
    }

    public void setAdditionalNotes(String passengerCount) {
        this.additionalNotes = passengerCount;
    }
}
