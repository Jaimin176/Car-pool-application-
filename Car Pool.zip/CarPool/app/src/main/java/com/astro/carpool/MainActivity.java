package com.astro.carpool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Base64;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private Button btnRegister;
    private EditText etEmail, etPassword, etName, etAddress, etConfirm, etPhone;
    private TextView txtClickLogin;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://car-pool-8de16-default-rtdb.firebaseio.com/");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnRegister = findViewById(R.id.registerBtn);
        etEmail = findViewById(R.id.editTextEmail);
        etPassword = findViewById(R.id.editTextPassword);
        etName = findViewById(R.id.editTextName);
        etAddress = findViewById(R.id.editTextAddress);
        etConfirm = findViewById(R.id.editTextConfirmPassword);
        etPhone = findViewById(R.id.editTextPhoneNumber);
        txtClickLogin = findViewById(R.id.clickLogin);


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signUpWithEmailPassword();
//                String Name = etName.getText().toString();
//                String PhoneNum = etPhone.getText().toString();
//                String Address = etAddress.getText().toString();
//                String Email = etEmail.getText().toString();
//                String Password = etPassword.getText().toString();
//                String ConfirmPassword = etConfirm.getText().toString();
//
//                if(Name.isEmpty() || PhoneNum.isEmpty() || Address.isEmpty() || Email.isEmpty() || Password.isEmpty() || ConfirmPassword.isEmpty()){
//                    Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_LONG).show();
//                }
//
//                else if(!Password.equals(ConfirmPassword)){
//                    Toast.makeText(MainActivity.this, "Passwords are not matching", Toast.LENGTH_LONG).show();
//                }
//                else{
//                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(@NonNull DataSnapshot snapshot) {
//                            if(snapshot.hasChild(PhoneNum)){
//                                Toast.makeText(MainActivity.this, "The account associated with this phone number is already registered", Toast.LENGTH_LONG).show();
//                            }
//                            else {
//                                databaseReference.child("users").child(PhoneNum).child("Name").setValue(Name);
//                                databaseReference.child("users").child(PhoneNum).child("Address").setValue(Address);
//                                //databaseReference.child("users").child(PhoneNum).child("Email").setValue(encodedEmail);
//                                databaseReference.child("users").child(PhoneNum).child("Password").setValue(Password);
//                                signUpWithEmailPassword();
//
//                            }
//                        }
//
//                        @Override
//                        public void onCancelled(@NonNull DatabaseError error) {
//
//                        }
//                    });

              //  }



            }
        });

        txtClickLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LoginPage.class);
                startActivity(intent);
            }
        });

        //reCaptcha verification
        SafetyNet.getClient(this).verifyWithRecaptcha("6LeuLEgpAAAAAAeIySnSiuTHkJq61Rm12CpQpriy")
                .addOnSuccessListener(this, new OnSuccessListener<SafetyNetApi.RecaptchaTokenResponse>(){

                    @Override
                    public void onSuccess(SafetyNetApi.RecaptchaTokenResponse response) {
                        //firebaseAuth = FirebaseAuth.getInstance();

                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
//        sendCodeButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String phoneNumber = phoneNoTxt.getText().toString().trim();
//                if(TextUtils.isEmpty(phoneNumber) || phoneNumber.length() < 10){
//                    phoneNoTxt.setError("Enter a valid phone number");
//                    phoneNoTxt.requestFocus();
//                    return;
//                }
//                Intent intent = new Intent(getApplicationContext(), CodeVerificationPage.class);
//                intent.putExtra("PhoneNumber", phoneNumber);
//                Log.d("Phone Number", phoneNumber);
//                startActivity(intent);
//                //sendVerificationCode(phoneNumber);
//            }
//        });
    }

    //method to handle email/password authentication
    public void signUpWithEmailPassword(){
        String Name = etName.getText().toString();
        String PhoneNum = etPhone.getText().toString();
        String Address = etAddress.getText().toString();
        String Email = etEmail.getText().toString();
        String Password = etPassword.getText().toString();
        String ConfirmPassword = etConfirm.getText().toString();

//        if(Name.isEmpty() || PhoneNum.isEmpty() || Address.isEmpty() || Email.isEmpty() || Password.isEmpty() || ConfirmPassword.isEmpty()){
//            Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_LONG).show();
//        }
//
//        else if(!Password.equals(ConfirmPassword)){
//            Toast.makeText(MainActivity.this, "Passwords are not matching", Toast.LENGTH_LONG).show();
//        }
//        else{
//            databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    if(snapshot.hasChild(PhoneNum)){
//                        Toast.makeText(MainActivity.this, "The account associated with this phone number is already registered", Toast.LENGTH_LONG).show();
//                    }
//                    else {
//                        databaseReference.child("users").child(PhoneNum).child("Name").setValue(Name);
//                        databaseReference.child("users").child(PhoneNum).child("Address").setValue(Address);
//                        //databaseReference.child("users").child(PhoneNum).child("Email").setValue(encodedEmail);
//                        databaseReference.child("users").child(PhoneNum).child("Password").setValue(Password);
//                        signUpWithEmailPassword();
//
//                    }
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//
//                }
//            });

        //}
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if(TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            //Handle empty email or password
            showSnackbar("Invalid email address");
            return;
        }
        if(TextUtils.isEmpty(Name)){
            showSnackbar("Please enter your Name");
            return;
        }
        if(TextUtils.isEmpty(Address)){
            showSnackbar("Please enter your address");
            return;
        }
        if(!isNumberValid(PhoneNum)){
            showSnackbar("Please enter valid Phone number");
        }
        if(TextUtils.isEmpty(password)){
            showSnackbar("Password cannot be empty");
            return;
        }
        if (!isPasswordValid(password)) {
            showSnackbar("Password must be at least 6 characters long and include uppercase, lowercase, and a number");
            return;
        }

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if(task.isSuccessful()){
                        Log.d("Email: ", "signUpWithEmail:Success");
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.hasChild(PhoneNum)){
                                    Toast.makeText(MainActivity.this, "The account associated with this phone number is already registered", Toast.LENGTH_LONG).show();
                                }
                                else {
                                    databaseReference.child("users").child(PhoneNum).child("Name").setValue(Name);
                                    databaseReference.child("users").child(PhoneNum).child("Address").setValue(Address);
                                    //databaseReference.child("users").child(PhoneNum).child("Email").setValue(encodedEmail);
                                    databaseReference.child("users").child(PhoneNum).child("Password").setValue(Password);
                                    signUpWithEmailPassword();

                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                        //navigate to next screen
                        Intent intent = new Intent(getApplicationContext(), HomePage.class);
                        intent.putExtra("User", user);
                        startActivity(intent);
                    } else{
                        Log.w("Email:", "signUpWithEmail: failure", task.getException());
                        handleAuthenticationException(task.getException());
                    }
                });
    }

    private void handleAuthenticationException(Exception exception){
        if (exception instanceof FirebaseAuthInvalidCredentialsException) {
            // Invalid email or password
            Log.e("EmailAuth", "Invalid email or password");
            showSnackbar("Invalid email or password");
        } else if (exception instanceof FirebaseAuthWeakPasswordException) {
            // Weak password
            Log.e("EmailAuth", "Weak password");
            showSnackbar("Weak password");
        } else if (exception instanceof FirebaseAuthUserCollisionException) {
            // Email already exists
            Log.e("EmailAuth", "Email already exists");
            showSnackbar("Email already exists");
        } else {
            // General authentication failure
            showSnackbar("Authentication failed");
            Log.e("EmailAuth", "Authentication failed", exception);
        }
    }

    private void showSnackbar(String message){
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT).show();
    }
    private boolean isPasswordValid(String password) {
        // Define your password constraints
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{6,}$";
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(password).matches();
    }

    private boolean isNumberValid(String num){
        String regex = "^\\+?[0-9\\-\\s\\.\\(\\)]{7,}$";
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(num).matches();
    }

}