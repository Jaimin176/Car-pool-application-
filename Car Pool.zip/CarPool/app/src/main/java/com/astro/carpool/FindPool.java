package com.astro.carpool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class FindPool extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap gMap;
    //private EditText pickupET, dropET, passCountET;
    private AutoCompleteTextView pickupET, dropET;
    private EditText passCountET;
    Button findBtn;
//    private Polyline polyline;
    public static int LOCATION_REQUEST_CODE = 100;
    double userLat;
    double userLng;
    private  LatLng destinationLocation, userLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    Handler handler;
    long refreshTime = 5000; //5sec
    Runnable runnable;
    private PlacesClient placesClient;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_pool);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        pickupET = findViewById(R.id.etPickUpPoint);
        dropET = findViewById(R.id.etDropPoint);
        passCountET = findViewById(R.id.etCount);
        findBtn = findViewById(R.id.btnFind);

        databaseReference = FirebaseDatabase.getInstance().getReference("pool_offers");

        Places.initialize(getApplicationContext(),"AIzaSyD3RzACKacttrthAoo1CuvPugWkTYRV7JI");
        placesClient = Places.createClient(this);
        setupAutoComplete();

        findBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pickup = pickupET.getText().toString();
                String dropoff = dropET.getText().toString();

                if (!TextUtils.isEmpty(pickup) && !TextUtils.isEmpty(dropoff)) {
                    Query query = databaseReference.orderByChild("pickUpPoint").equalTo(pickup);
                    query.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            List<OfferedPool> offeredPools = new ArrayList<>();
                            for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                                OfferedPool offeredPool = dataSnapshot.getValue(OfferedPool.class);
                                offeredPool.setId(dataSnapshot.getKey());
                                offeredPools.add(offeredPool);
                                if(offeredPool.getDropPoint().equals(dropoff)){
                                    Log.d("offeredPool", offeredPool.toString());
                                    offeredPools.add(offeredPool);
                                }
                            }

                            Log.d("offeredPools", offeredPools.toString());

                            if(!offeredPools.isEmpty()){
                                Intent intent = new Intent(FindPool.this, DisplayOffer.class);
                                intent.putExtra("offeredPools", (Serializable) offeredPools);
                                startActivity(intent);
                            }else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(FindPool.this);
                                builder.setMessage("No pools offered for this route.")
                                        .setPositiveButton("OK", null)
                                        .show();
                            }

                        }


                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Log.e("DatabaseError", "Failed to read value.", error.toException());
                        }
                    });
                    fetchLocationAndDrawRoute(pickup, dropoff);
                } else {
                    Toast.makeText(FindPool.this, "Please fill all the fields", Toast.LENGTH_LONG).show();
                }
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.findPool) {
                    return true;
                }
                if (item.getItemId() == R.id.offerPool) {
                    startActivity(new Intent(getApplicationContext(), OfferPool.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if (item.getItemId() == R.id.chats) {
                    startActivity(new Intent(getApplicationContext(), Messages.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if (item.getItemId() == R.id.home) {
                    startActivity(new Intent(getApplicationContext(), HomePage.class));
                    overridePendingTransition(0, 0);
                    return true;
                }

                return false;
            }
        });
        handler = new Handler();
        handler.postDelayed(runnable = new Runnable() {
            @Override
            public void run() {
                handler.postDelayed(runnable, refreshTime);
                checkLocationPermission();
            }
        }, refreshTime);

        //permissions
        checkLocationPermission();
    }

    private void fetchLocationAndDrawRoute(String pickup, String dropOff){
        //LatLng pickupL
    }
    private void setupAutoComplete() {
        List<TypeFilter> typeFilters = new ArrayList<>();
        typeFilters.add(TypeFilter.ADDRESS);
        typeFilters.add(TypeFilter.CITIES);

        pickupET.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line));
        pickupET.setThreshold(1);
        pickupET.setOnItemClickListener((parent, view, position, id) -> {
            // Retrieve the selected item
            AutocompletePrediction item = (AutocompletePrediction) parent.getItemAtPosition(position);
            // Use the place ID to query details about the selected place
            String placeId = item.getPlaceId();
        });

        dropET.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line));
        dropET.setThreshold(1);
        dropET.setOnItemClickListener((parent, view, position, id) -> {
            // Retrieve the selected item
            AutocompletePrediction item = (AutocompletePrediction) parent.getItemAtPosition(position);
            // Use the place ID to query details about the selected place
            String placeId = item.getPlaceId();
        });


    }

    private void checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getUserLocation();
        } else {
            requestForPermission();
        }
    }

    private void getUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                     userLat = location.getLatitude();
                     userLng = location.getLongitude();

                    userLocation = new LatLng(userLat, userLng);

                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(userLocation)
                            .zoom(12)
                            .build();
                    if (gMap != null) {
                        gMap.clear();
                        gMap.addMarker(new MarkerOptions().position(userLocation).title("I'm Here"));
                    }
                    //gMap.addMarker(new MarkerOptions().position(userLocation).title("I'm Here"));
                    gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 12f));
                    gMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

                    Log.i("XOXO", "" + userLat + " " + userLng);
                }
            }
        });
    }

    private void requestForPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Accepted", Toast.LENGTH_LONG).show();
                getUserLocation();
            } else {
                Toast.makeText(this, "Permission Rejected", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        gMap = googleMap;
        gMap.getUiSettings().setMyLocationButtonEnabled(true);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        gMap.setMyLocationEnabled(true);
        gMap.getUiSettings().setZoomControlsEnabled(true);
        gMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                gMap.clear();
                destinationLocation = latLng;
                googleMap.addMarker(new MarkerOptions().position(destinationLocation).title("Destination"));
                gMap.addPolyline((new PolylineOptions()).add(userLocation, destinationLocation).
                        width(5)
                        .color(Color.RED)
                        .geodesic(true));
                gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 13));
            }
        });
        getUserLocation();

//        LatLng location = new LatLng(23.00485106771381, 72.51832456439313);
//        googleMap.addMarker(new MarkerOptions().position(location).title("Amisha's PG"));
//        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12f));
//        googleMap.animateCamera(CameraUpdateFactory.zoomTo(12f));
    }

//    private void drawRoute(List<HashMap<String, String>> routeList){
//        if(gMap == null){
//            return;
//        }
//
//        if(polyline != null){
//            polyline.remove();
//        }
//
//        ArrayList<LatLng> points = new ArrayList<>();
//        PolylineOptions polylineOptions = new PolylineOptions();
//
//        for(int i = 0; i < routeList.size(); i++){
//            HashMap<String, String> point = routeList.get(i);
//
//            double lat = Double.parseDouble(point.get("lat"));
//            double lng = Double.parseDouble(point.get("lng"));
//            LatLng position = new LatLng(lat, lng);
//
//            points.add(position);
//        }
//
//        polylineOptions.addAll(points);
//        polylineOptions.width(10);
//        polylineOptions.color(Color.RED);
//        polylineOptions.geodesic(true);
//
//        polyline = gMap.addPolyline(polylineOptions);
//    }
//
//    private  class DrawRouteTask extends AsyncTask<String, Void, String>{
//        @Override
//        protected String doInBackground(String... params) {
//            String responseString = "";
//
//            try{
//                String pickup = params[0];
//                String dropoff = params[1];
//                String url = "https://maps.googleapis.com/maps/api/directions/json?origin=" + pickup + "&destination=" + dropoff + "&key=AIzaSyD3RzACKacttrthAoo1CuvPugWkTYRV7JI";
//                URL apiUrl = new URL(url);
//                HttpURLConnection httpURLConnection = (HttpURLConnection) apiUrl.openConnection();
//                httpURLConnection.connect();
//
//                InputStream inputStream = httpURLConnection.getInputStream();
//                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
//                StringBuilder stringBuilder = new StringBuilder();
//                String line;
//                while ((line = bufferedReader.readLine()) != null){
//                    stringBuilder.append(line);
//                }
//
//                responseString = stringBuilder.toString();
//
//                bufferedReader.close();
//                inputStream.close();
//                httpURLConnection.disconnect();
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//            return responseString;
//        }
//        @Override
//        protected void onPostExecute(String responseString) {
//            super.onPostExecute(responseString);
//
//            List<HashMap<String, String>> routeList = parseJson(responseString);
//            drawRoute(routeList);
//        }
//    }
//
//    private List<HashMap<String, String>> parseJson(String json) {
//        List<HashMap<String, String>> routeList = new ArrayList<>();
//
//        try {
//            JSONObject jsonObject = new JSONObject(json);
//            JSONArray routes = jsonObject.getJSONArray("routes");
//
//            for (int i = 0; i < routes.length(); i++) {
//                JSONObject route = routes.getJSONObject(i);
//                JSONArray legs = route.getJSONArray("legs");
//
//                for (int j = 0; j < legs.length(); j++) {
//                    JSONObject leg = legs.getJSONObject(j);
//                    JSONArray steps = leg.getJSONArray("steps");
//
//                    for (int k = 0; k < steps.length(); k++) {
//                        JSONObject step = steps.getJSONObject(k);
//                        JSONObject startLocation = step.getJSONObject("start_location");
//                        double startLat = startLocation.getDouble("lat");
//                        double startLng = startLocation.getDouble("lng");
//
//                        HashMap<String, String> point = new HashMap<>();
//                        point.put("lat", String.valueOf(startLat));
//                        point.put("lng", String.valueOf(startLng));
//                        routeList.add(point);
//                    }
//                }
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        return routeList;
//    }

}