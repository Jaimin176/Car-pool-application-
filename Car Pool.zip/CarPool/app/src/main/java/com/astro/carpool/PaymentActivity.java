package com.astro.carpool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

public class PaymentActivity extends AppCompatActivity {
    TextInputEditText upiId, amount;
    Button payBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        upiId = findViewById(R.id.edit_text_upiId);
        amount = findViewById(R.id.edit_text_amount);

        payBtn = findViewById(R.id.payBtn);
        payBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PaymentGatewayStart();
            }
        });
    }

    public void PaymentGatewayStart(){
        double price;
        Intent intent = getIntent();
        if(intent != null){
            price = intent.getDoubleExtra("price", 0.0);
        }
       // EasyUpiPayment.Builder
    }
}