package com.astro.carpool;
import java.io.Serializable;

public class OfferedPool implements Serializable{
    private String date;
    private String time;
    private String pickUpPoint;
    private String dropPoint;
    private String passengerCount;
    private String vehicleType;
    private String price;
    private String id;
    public OfferedPool(){}

    public OfferedPool(String pickupLocation, String dropoffLocation, String date,String time, String availableSeats,
                     String price, String vehicleType, String id){
        this.pickUpPoint = pickupLocation;
        this.dropPoint = dropoffLocation;
        this.date = date;
        this.time = time;
        this.passengerCount = availableSeats;
        this.price = price;
        this.vehicleType = vehicleType;
        this.id = id;

    }


    //    public String getDate() {
//        return date;
//    }
//
//    public String getTime() {
//        return time;
//    }
//
//    public String getPickUpPoint() {
//        return pickUpPoint;
//    }
//
//    public String getDropPoint() {
//        return dropPoint;
//    }
//
//    public String getPassengerCount() {
//        return passengerCount;
//    }
//
//    public String getVehicleType(){
//        return vehicleType;
//    }
//
//    public String getPrice(){
//        return price;
//    }

    public String getId() {
        return id;
    }

    public void setId(String poolId) {
        this.id = poolId;
    }

    public String getDate() {
    return date;
}

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPickUpPoint() {
        return pickUpPoint;
    }

    public void setPickUpPoint(String pickUpPoint) {
        this.pickUpPoint = pickUpPoint;
    }

    public String getDropPoint() {
        return dropPoint;
    }

    public void setDropPoint(String dropPoint) {
        this.dropPoint = dropPoint;
    }

    public String getPassengerCount() {
        return passengerCount;
    }

    public void setPassengerCount(String passengerCount) {
        this.passengerCount = passengerCount;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String passengerCount) {
        this.price = passengerCount;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

//    public String getAdditionalNotes() {
//        return a;
//    }
//
//    public void setAdditionalNotes(String passengerCount) {
//        this.additionalNotes = passengerCount;
//    }
}
