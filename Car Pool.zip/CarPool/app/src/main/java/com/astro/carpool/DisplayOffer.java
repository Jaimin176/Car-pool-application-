package com.astro.carpool;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

public class DisplayOffer extends AppCompatActivity {
    private RecyclerView recyclerView;
    private OfferedPoolAdapter adapter;
    private List<OfferedPool> offeredPools;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_offer);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        offeredPools = (List<OfferedPool>) getIntent().getSerializableExtra("offeredPools");
        adapter = new OfferedPoolAdapter(getApplicationContext(),offeredPools);
        recyclerView.setAdapter(adapter);


    }
}