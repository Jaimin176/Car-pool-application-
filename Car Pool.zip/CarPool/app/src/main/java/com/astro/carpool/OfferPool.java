package com.astro.carpool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class OfferPool extends AppCompatActivity{

    private EditText pickupEt, dropOffEt, dateEt, timeEt, seatEt, priceEt, vehicleEt, NoteEt;
    Button btnOfferPool;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offer_pool);

        pickupEt = findViewById(R.id.etPickupLocation);
        dropOffEt = findViewById(R.id.etDropoffLocation);
        dateEt = findViewById(R.id.etDate);
        timeEt = findViewById(R.id.etTime);
        seatEt = findViewById(R.id.etAvailableSeats);
        priceEt = findViewById(R.id.etPrice);
        vehicleEt = findViewById(R.id.etVehicleType);
        NoteEt = findViewById(R.id.etAdditionalNotes);
        btnOfferPool = findViewById(R.id.btnOfferPool);

        dateEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePicker();
            }
        });

        timeEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePicker();
            }
        });

        btnOfferPool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                offerPool(view);
            }
        });

        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://car-pool-8de16-default-rtdb.firebaseio.com/").child("pool_offers");

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener(){

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.findPool){
                    startActivity(new Intent(getApplicationContext(), FindPool.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                if(item.getItemId() == R.id.offerPool){
                    return true;
                }
                if (item.getItemId() == R.id.chats) {
                    startActivity(new Intent(getApplicationContext(), Messages.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if (item.getItemId() == R.id.home){
                    startActivity(new Intent(getApplicationContext(), HomePage.class));
                    overridePendingTransition(0,0);
                    return true;
                }

                return false;
            }
        });
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int mYear = calendar.get(Calendar.YEAR);
        int mMonth = calendar.get(Calendar.MONTH);
        int mDay = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        dateEt.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                        //showTimePicker();
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private void showTimePicker() {
        final Calendar calendar = Calendar.getInstance();
        int mHour = calendar.get(Calendar.HOUR_OF_DAY);
        int mMinute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        timeEt.setText(hourOfDay + ":" + minute);
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }

    private void offerPool(View view){
        String pickupLocation = pickupEt.getText().toString().trim();
        String dropoffLocation = dropOffEt.getText().toString().trim();
        String date = dateEt.getText().toString().trim();
        String time = timeEt.getText().toString().trim();
        String availableSeats = seatEt.getText().toString().trim();
        String price = priceEt.getText().toString().trim();
        String vehicleType = vehicleEt.getText().toString().trim();
        String additionalNotes = NoteEt.getText().toString().trim();

        if (!pickupLocation.isEmpty() && !dropoffLocation.isEmpty() && !date.isEmpty() && !time.isEmpty()
                && !availableSeats.isEmpty() && !price.isEmpty() && !vehicleType.isEmpty()){
            String poolId = databaseReference.push().getKey();
            databaseReference.child(poolId)
                    .setValue(new PoolOffer(pickupLocation, dropoffLocation, date, time, availableSeats, price, vehicleType, additionalNotes));
            Toast.makeText(this, "Pool offered successfully!", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Please fill in all details", Toast.LENGTH_LONG).show();
        }
    }

}