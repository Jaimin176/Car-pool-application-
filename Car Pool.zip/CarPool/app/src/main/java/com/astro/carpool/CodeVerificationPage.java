package com.astro.carpool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class CodeVerificationPage extends AppCompatActivity {

    private EditText digit1, digit2, digit3, digit4, digit5, digit6;
    private FirebaseAuth firebaseAuth;
    private String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_verification_page);

        firebaseAuth = FirebaseAuth.getInstance();
        Intent intent = getIntent();
        String phoneCode = "+91";
        String phoneNumber = phoneCode.concat(intent.getExtras().getString("PhoneNumber"));
        Log.d("Phone Number", phoneNumber);
        sendVerificationCode(phoneNumber);

        digit1 = findViewById(R.id.digit1EditText);
        digit2 = findViewById(R.id.digit2EditText);
        digit3 = findViewById(R.id.digit3EditText);
        digit4 = findViewById(R.id.digit4EditText);
        digit5 = findViewById(R.id.digit5EditText);
        digit6 = findViewById(R.id.digit6EditText);

        setUpDigitEditTextListeners();
    }

    private void setUpDigitEditTextListeners() {
        digit1.addTextChangedListener(new DigitTextWatcher(digit1, digit2));
        digit2.addTextChangedListener(new DigitTextWatcher(digit2, digit3));
        digit3.addTextChangedListener(new DigitTextWatcher(digit3, digit4));
        digit4.addTextChangedListener(new DigitTextWatcher(digit4, digit5));
        digit5.addTextChangedListener(new DigitTextWatcher(digit5, digit6));
    }

    private static class DigitTextWatcher implements TextWatcher{
        private final EditText currentDigitEditText;
        private final EditText nextDigitEditText;

        DigitTextWatcher(EditText currentDigitEditText, EditText nextDigitEditText){
            this.currentDigitEditText = currentDigitEditText;
            this.nextDigitEditText = nextDigitEditText;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            if(editable.length() == 1){
                nextDigitEditText.requestFocus();
            }
        }
    }

    //method to send verification code
    private void sendVerificationCode(String phoneNumber) {
        PhoneAuthProvider.verifyPhoneNumber(
                PhoneAuthOptions.newBuilder(firebaseAuth)
                        .setPhoneNumber(phoneNumber)
                        .setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                // Auto-retrieval of verification code is successful.
                                signInWithPhoneAuthCredential(phoneAuthCredential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Log.e("PhoneAuth", "onVerificationFailed", e);
                                // Verification failed, handle the error
                                // For example, display a toast message
                            }

                            @Override
                            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                // Code has been sent to the provided phone number
                                // Save the verification ID and start a new activity to enter the code
                                verificationId = s;
                            }
                        })
                        .build());
    }

    public void verifyCode(View view) {
        String code1 = digit1.getText().toString().trim();
        String code2 = code1.concat(digit2.getText().toString().trim());
        String code3 = code2.concat(digit3.getText().toString().trim());
        String code4 = code3.concat(digit4.getText().toString().trim());
        String code5 = code4.concat(digit5.getText().toString().trim());
        String verificationCode = code5.concat(digit6.getText().toString().trim());

        // Validate verification code
        if (TextUtils.isEmpty(verificationCode) || verificationCode.length() < 6) {
            digit6.setError("Enter a valid verification code");
            digit6.requestFocus();
            return;
        }

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, verificationCode);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(),"Login Successfull", Toast.LENGTH_SHORT );
                            // Sign in success, update UI or navigate to the next activity
                            // For example, startActivity(new Intent(PhoneNumberAuthenticationActivity.this, HomeActivity.class));
                        } else {
                            Toast.makeText(getApplicationContext(),"Invalid Code", Toast.LENGTH_SHORT );
                            // If sign in fails, display a message to the user.
                            // For example, display a toast message
                        }
                    }
                });
    }

//    private void sendVerificationCode(String phoneNumber){
//        PhoneAuthProvider.verifyPhoneNumber(
//                PhoneAuthOptions.newBuilder(firebaseAuth)
//                        .setPhoneNumber(phoneNumber)
//                        .setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
//                        .setActivity(this)
//                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
//                            @Override
//                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
//
//                            }
//
//                            @Override
//                            public void onVerificationFailed(@NonNull FirebaseException e) {
//
//                            }
//                        })
//        );
//    }
}