package com.astro.carpool;

import static androidx.core.content.ContextCompat.startActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class OfferedPoolAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private  Context context;
    private List<OfferedPool> offeredPools;

    public OfferedPoolAdapter(Context context, List<OfferedPool> offeredPools){
        this.context = context;
        this.offeredPools = offeredPools;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_offered_pool, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        OfferedPool offeredPool = offeredPools.get(position);
        holder.textDate.setText(offeredPool.getDate());
        holder.textTime.setText(offeredPool.getTime());
        holder.textPickUpPoint.setText(offeredPool.getPickUpPoint());
        holder.textDropPoint.setText(offeredPool.getDropPoint());
        holder.textPassengerCount.setText(offeredPool.getPassengerCount());
        holder.textVehicleType.setText(offeredPool.getVehicleType());
        holder.textPrice.setText(offeredPool.getPrice());


        holder.btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                sendNotification();
                Context context = view.getContext();

                //Toast.makeText(context,"You have accpeted the offered Pool", Toast.LENGTH_LONG).show();
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage("You have accepted this offered pool.")
                        .setPositiveButton("OK", null)
                        .show();

//                Intent intent = new Intent(context, PaymentActivity.class);
//                intent.putExtra("price", offeredPool.getPrice());
//                context.startActivity(intent);
                //String poolId = offeredPool.getId();
               // Log.d("Pool Id", poolId);
               // DatabaseReference poolRef = FirebaseDatabase.getInstance().getReference("pool_offers").child(poolId);
                //poolRef.removeValue()
//                        .addOnSuccessListener(new OnSuccessListener<Void>() {
//                            @Override
//                            public void onSuccess(Void unused) {
//                                Log.d("message", "Offered pool deleted successfully");
//                            }
//                        })
//                        .addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception e) {
//                                Log.d("message", "Offered pool deletion unsuccessful");
//                            }
//                        });
            }
        });
    }
    private  void sendNotification(){

    }

    @Override
    public int getItemCount() {
        return offeredPools.size();
    }


//    public static class ViewHolder extends RecyclerView.ViewHolder {
//        TextView textDate, textTime, textPickUpPoint, textDropPoint, textPassengerCount, textVehicleType, textPrice;
//
//        public ViewHolder(@NonNull View itemView) {
//            super(itemView);
//            textDate = itemView.findViewById(R.id.showDate);
//            textTime = itemView.findViewById(R.id.showTime);
//            textPickUpPoint = itemView.findViewById(R.id.textFrom);
//            textDropPoint = itemView.findViewById(R.id.textDestination);
//            textPassengerCount = itemView.findViewById(R.id.textSeats);
//            textVehicleType = itemView.findViewById(R.id.showSeats);
//            textPrice = itemView.findViewById(R.id.showPrice);
//        }
//    }
}

class MyViewHolder extends  RecyclerView.ViewHolder{
    TextView textDate, textTime, textPickUpPoint, textDropPoint, textPassengerCount, textVehicleType, textPrice;
    Button btnAccept;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        textDate = itemView.findViewById(R.id.showDate);
        textTime = itemView.findViewById(R.id.showTime);
        textPickUpPoint = itemView.findViewById(R.id.textSource);
        textDropPoint = itemView.findViewById(R.id.textDestination);
        textPassengerCount = itemView.findViewById(R.id.showSeats);
        textVehicleType = itemView.findViewById(R.id.showType);
        textPrice = itemView.findViewById(R.id.showPrice);
        btnAccept = itemView.findViewById(R.id.acceptBtn);
    }
}
