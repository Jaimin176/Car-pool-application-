package com.astro.carpool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;

import java.util.regex.Pattern;

public class LoginPage extends AppCompatActivity {

    private ImageButton btnLogin;
    private EditText etEmail2, etPassword2;
    private TextView txtClickSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        btnLogin = findViewById(R.id.loginBtn);
        etEmail2 = findViewById(R.id.emailET2);
        etPassword2 = findViewById(R.id.passwordET2);
        txtClickSignUp = findViewById(R.id.clickSignUp);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signInWithEmailPassword();
            }
        });

        txtClickSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               goBack();
            }
        });

        //reCaptcha verification
        SafetyNet.getClient(this).verifyWithRecaptcha("6LeuLEgpAAAAAAeIySnSiuTHkJq61Rm12CpQpriy")
                .addOnSuccessListener(this, new OnSuccessListener<SafetyNetApi.RecaptchaTokenResponse>(){

                    @Override
                    public void onSuccess(SafetyNetApi.RecaptchaTokenResponse response) {
                        //firebaseAuth = FirebaseAuth.getInstance();

                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }
    private void goBack(){
        finish();
    }

    public void signInWithEmailPassword(){
        String email = etEmail2.getText().toString().trim();
        String password = etPassword2.getText().toString().trim();

        if(TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            //Handle empty email or password
            showSnackbar("Invalid email address");
            return;
        }
        if(TextUtils.isEmpty(password)){
            showSnackbar("Password cannot be empty");
            return;
        }
        if (!isPasswordValid(password)) {
            showSnackbar("Password must be at least 6 characters long and include uppercase, lowercase, and a number");
            return;
        }

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if(task.isSuccessful()){
                        Log.d("Email: ", "signInWithEmail:Success");
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        //navigate to next screen
                        Intent intent = new Intent(getApplicationContext(), HomePage.class);
                        intent.putExtra("User", user);
                        startActivity(intent);
                    } else{
                        Log.w("Email:", "signInWithEmail: failure", task.getException());
                        handleAuthenticationException(task.getException());
                    }
                });
    }

    private void handleAuthenticationException(Exception exception){
        if (exception instanceof FirebaseAuthInvalidCredentialsException) {
            // Invalid email or password
            Log.e("EmailAuth", "Invalid email or password");
            showSnackbar("Invalid email or password");
        } else if (exception instanceof FirebaseAuthWeakPasswordException) {
            // Weak password
            Log.e("EmailAuth", "Weak password");
            showSnackbar("Weak password");
        } else if (exception instanceof FirebaseAuthUserCollisionException) {
            // Email already exists
            Log.e("EmailAuth", "Email already exists");
            showSnackbar("Email already exists");
        } else {
            // General authentication failure
            showSnackbar("Authentication failed");
            Log.e("EmailAuth", "Authentication failed", exception);
        }
    }
    private void showSnackbar(String message){
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT).show();
    }

    private boolean isPasswordValid(String password) {
        // Define your password constraints
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{6,}$";
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(password).matches();
    }
}